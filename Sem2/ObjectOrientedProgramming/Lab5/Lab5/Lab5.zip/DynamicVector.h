#pragma once
#include <stdexcept>

template <class T>
class DynamicVector {
private: 
	T* elements_;
	int size_, capacity_;
    void resize();
public: 
  DynamicVector();
  DynamicVector(DynamicVector<T> const&);
  ~DynamicVector();
  void push_back(T const&);
  void pop_back(int);
  T& at(int) const;
  void insert(T, int);
  int get_size() const;
};

template<class T>
inline void DynamicVector<T>::resize()
{
  capacity_ *= 2;
  T *newElements = new T[capacity_];
  int index = 0;
  for (int i = 0; i < size_; i++) {
    newElements[i] = elements_[i];
  }
  delete[] elements_;
    elements_ = newElements;
}

template<class T>
inline DynamicVector<T>::DynamicVector()
{
  size_ = 0;
  capacity_ = 10;
  elements_ = new T[10];
}

template<class T>
inline DynamicVector<T>::DynamicVector(DynamicVector<T> const& vector){
  size_ = vector.size_;
  capacity_ = vector.capacity_;
  elements_ = new T[capacity_];
  for (int i = 0; i < size_; i++) {
    elements_[i] = vector.elements_[i];
  }
}

template<class T>
inline DynamicVector<T>::~DynamicVector()
{
  delete[] elements_;
}

template<class T>
inline void DynamicVector<T>::push_back(T const& element)
{
  if (size_ == capacity_) {
    resize();
 }
  elements_[size_++] = element;
}

template<class T>
void DynamicVector<T>::pop_back(int position)
{
  if (position < size_ && position > -1) {

    for (auto i = position; i < size_; i++) {
      elements_[i] = elements_[i + 1];
    }
    size_--;
  } else {
      throw std::invalid_argument("value out of bounds");
  }
  
}

template<class T>
inline T& DynamicVector<T>::at(int position) const
{
  if (position < size_ && position > -1) {
    return elements_[position];
  }
  throw std::invalid_argument("value out of bounds");
}

template<class T>
inline void DynamicVector<T>::insert(T element, int position)
{
  if (position < size_ && position > -1) {
   if (size_ == capacity_) {
     resize();
   }
    size_++;
    for (int i = size_ - 1; i > position; i--) {
      elements_[i] = elements_[i - 1];
    }
    elements_[position] = element;
  } else {
    throw std::invalid_argument("Index out of bounds");
  }
}

template<class T>
inline int DynamicVector<T>::get_size() const
{
  return size_;
}

