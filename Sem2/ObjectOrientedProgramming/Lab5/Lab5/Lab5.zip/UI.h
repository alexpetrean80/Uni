#pragma once
#include <iostream>
#include <sstream>
#include <algorithm>
#include "Service.h"

class UI
{
private:
  Service service;
public:
  void read_command(DynamicVector<std::string>&);
  void menu();
};
