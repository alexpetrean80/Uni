#include "Service.h"


Service::Service() { mode = "A"; }

void Service::set_mode(const std::string new_mode)
{ mode = new_mode; }

void Service::add_statue(std::string powerWordName, std::string material, int age, std::string corporealForm)
{
  if (mode == "A") {
      GuardianStatue* statue =
    new GuardianStatue(powerWordName, material, age, corporealForm);
  repo_.add(*statue);
  delete statue;
  } else {
    throw std::exception(
        "You are but an apprentice, you shouldn't tinker with such power!");
  }
  

}

void Service::delete_statue(std::string powerWordName) {
  if (mode == "A") {
      repo_.remove(powerWordName);
  } else {
    throw std::exception(
        "You are but an apprentice, you shouldn't tinker with such power!");
  }
  
}

void Service::update_statue(std::string powerWordName,
                      std::string material,
                      int age,
                      std::string corporealForm)
{
  if (mode == "A") {
      GuardianStatue* statue =
    new GuardianStatue(powerWordName, material, age, corporealForm);
  repo_.update(*statue);
  delete statue;
  } else {
    throw std::exception(
        "You are but an apprentice, you shouldn't tinker with such power!");
  }
  
}

DynamicVector<GuardianStatue> const&
Service::get_statues() {
  return repo_.getStatues();
}
