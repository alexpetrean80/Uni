#include "Repo.h"

void Repo::add(GuardianStatue const& statue)
{
  elements_.push_back(statue);
}

void Repo::remove(const std::string& powerWordName) {
  for (int i = 0; i < elements_.get_size(); i++) {
    if (elements_.at(i).get_power_word_name() == powerWordName) {
      elements_.pop_back(i);
    }
  }
}

void Repo::update(GuardianStatue &statue) {
  for (auto i = 0; i < elements_.get_size(); i++) {
    if (elements_.at(i).get_power_word_name() == statue.get_power_word_name()) {
      elements_.at(i) = statue;
      return;
    }
  }
}

DynamicVector<GuardianStatue> const& Repo::getStatues() const
{
  return elements_;
}
