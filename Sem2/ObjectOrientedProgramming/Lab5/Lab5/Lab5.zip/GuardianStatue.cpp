#include "GuardianStatue.h"

GuardianStatue::GuardianStatue() {
  this->power_word_name_ = "";
  this->material_ = "";
  this->age_ = 0;
  this->corporeal_form_ = "";
}

GuardianStatue::GuardianStatue(std::string powerWordName, std::string material, int age, std::string corporealForm) {
  this->power_word_name_ = powerWordName;
  this->material_ = material;
  this->age_ = age;
  this->corporeal_form_ = corporealForm;
}

GuardianStatue::GuardianStatue(GuardianStatue const& guardian) {
  *this = guardian;
}

GuardianStatue::~GuardianStatue() {}

std::string GuardianStatue::get_power_word_name() const {
  return this->power_word_name_;
}

void GuardianStatue::set_power_word_name(std::string powerWordName) {
  this->power_word_name_ = std::move(powerWordName);
}

std::string GuardianStatue::get_material() const
{
  return this->material_;
}

void GuardianStatue::set_material(std::string material) {
  this->material_ = std::move(material);
}

int GuardianStatue::get_age() {
  return this->age_;
}

void GuardianStatue::set_age(int age) {
  this->age_ = age;
}

std::string GuardianStatue::get_corporeal_form() const
{
  return this->corporeal_form_;
}

void GuardianStatue::set_corporeal_form(std::string corporealForm) {
  this->corporeal_form_ = std::move(corporealForm);
}

std::string GuardianStatue::to_string() const
{
  std::stringstream result;
  result << power_word_name_ << " ";
  result << material_ << " ";
  result << age_ << " ";
  result << corporeal_form_;
  return result.str();
}

bool GuardianStatue::operator==(GuardianStatue const& statue) const
{
  return power_word_name_ == statue.power_word_name_ && material_ == statue.material_ && age_ == statue.age_ && corporeal_form_ == statue.corporeal_form_;
}

bool GuardianStatue::operator!=(GuardianStatue const& statue) const
{
    return power_word_name_ != statue.power_word_name_ || material_ != statue.material_ || age_ != statue.age_ || corporeal_form_ != statue.corporeal_form_;
}

GuardianStatue& GuardianStatue::operator=(GuardianStatue const& statue)
{
  if (this == &statue) {
    return *this;
  }
  power_word_name_ = statue.power_word_name_;
  material_ = statue.material_;
  age_ = statue.age_;
  corporeal_form_ = statue.corporeal_form_;
  return *this;
}
